# bilibili_ffmpeg_course
# 哔哩哔哩的音视频课程源码
# FFMPEG版本3.1.1
# 开发语言：c++
# 编译器：vs2019
# 交流群：661577854(源码不包括FFMpeg，请移步群文件下载)
# FFMpeg的三个文件请放置在project目录下
# 并在vs编辑器的项目属性中，调整include、lib库的加载路径及输出目录到bin目录下。即可运行
